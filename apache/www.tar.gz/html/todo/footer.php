<div id="footer">
  <div class="copyright">Bad Todo Ver 1.1.0 &copy; 2018-2022 Hiroshi Tokumaru</div>
</div><!-- /#footer-->
