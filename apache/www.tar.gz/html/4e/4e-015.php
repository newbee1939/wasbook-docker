<?php
    unlink('/var/www/html/xinfo.php');
?>攻撃コードを削除しました


