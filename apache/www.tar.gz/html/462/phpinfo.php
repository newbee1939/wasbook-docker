<?php
  phpinfo();
