<?php
  header("Location: https://www.yahoo.co.jp\r\nSet-Cookie: AAA=BBB;");
