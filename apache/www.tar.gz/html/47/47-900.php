<html>
<head><title>ログインエラー</title></head>
<body>
IDまたはパスワードが違います。再度認証してください。
<form action="47-901.php" method="POST">
ユーザ名<input type="text" name="id"><BR>
パスワード<input type="password" name="pwd"><BR>
<input type="submit" value="ログイン">
</form>
</body>
</html>
