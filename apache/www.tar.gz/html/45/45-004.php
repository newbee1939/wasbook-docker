<?php
  session_start();
  // ログイン確認…省略
?>
<body>
<body>
<form action="45-005.php" method="post" enctype="multipart/form-data">
ファイル：<input type="file" name="imgfile" size="20"><br>
<input type="submit" value="アップロード">
</form>
</body>
