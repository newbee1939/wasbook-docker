<?php
  session_start();
  // ログイン確認…省略
?>
<body>
<form action="45-003.php" method="POST">
新パスワード<input name="pwd" type="password"><BR>
<input type=submit value="パスワード変更">
</form>
</body>
