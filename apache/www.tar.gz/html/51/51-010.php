<?php
  session_start();
  $_SESSION['id'] = 'yamada';
?>
<body>
ログインしました(id=yamada)<br>
<a href="51-011.php">next</a>
</body>
