<html>
<head><title>個人情報入力</title></head>
<body>
<form action="31-003.php" method="POST">
氏名<input type="text" name="name"><BR>
メールアドレス<input type="text" name="mail"><BR>
性別<input type="radio" name="gender" value="女">女
<input type="radio" name="gender" value="男">男<BR>
<input type="submit" value="確認">
</form>
</body></html>
