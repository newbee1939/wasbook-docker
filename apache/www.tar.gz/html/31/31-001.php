<body>
<?php echo htmlspecialchars(date('G:i')); ?>
</body>
